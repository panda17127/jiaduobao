module.exports = {
	'/root/': {
		target: 'http://114.55.72.164:8091/',
		changeOrigin: true
	}
}