/*
 * @Description: 返回数据模板
 * @Author: gaosong
 * @LastEditors: gaosong
 * @Date: 2019-03-12 10:35:23
 * @LastEditTime: 2019-03-12 15:56:32
 */

let userInfo = {
  code: 200,
  id: '123456',
  msg: 'success',
  name: 'gs',
  tel: '12306'
}

let user = {
  userInfo
}

export default user
