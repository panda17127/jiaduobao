// global
export const SET_NUM = 'SET_NUM'
