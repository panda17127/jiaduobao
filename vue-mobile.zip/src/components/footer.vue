<template>
  <div class="footer">
    <div>1222</div>
    <div>
        <img src="../assets/imgs/page_footer_one.png" alt="">
        <img src="../assets/imgs/page_footer_two.png" alt="">
        <img src="../assets/imgs/page_footer_three.png" alt="">
    </div>
  </div>
</template>
<script>
export default {
}
</script>
<style lang="less" scoped>
@import "~styles/index.less";
@import "~styles/variable.less";
</style>
